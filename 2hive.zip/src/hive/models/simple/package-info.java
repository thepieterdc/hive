/**
 * Simple models.
 * <p>
 * Created at 3/05/16 19:29
 *
 * @author <a href="mailto:pieterdeclercq@outlook.com">Pieter De Clercq</a>
 */
package hive.models.simple;