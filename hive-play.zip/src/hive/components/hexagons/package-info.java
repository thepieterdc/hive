/**
 * Different types of Hexagons.
 * <p>
 * Created at 22/04/16 9:02
 *
 * @author <a href="mailto:pieterdeclercq@outlook.com">Pieter De Clercq</a>
 */
package hive.components.hexagons;