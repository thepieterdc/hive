/**
 * Components specifically for the Viewer-mode.
 * <p>
 * Created at 1/04/16 19:18
 *
 * @author <a href="mailto:pieterdeclercq@outlook.com">Pieter De Clercq</a>
 */
package hive.components.viewer;