/**
 * Pathfinding, navigation classes.
 * <p>
 * Created at 28/04/16 20:32
 *
 * @author <a href="mailto:pieterdeclercq@outlook.com">Pieter De Clercq</a>
 */
package hive.helpers.pathfinding;