# Sources

### MovesButton vectors
https://github.com/FortAwesome/Font-Awesome (SIL OFL 1.1 license)

### JavaFX jUnit library
https://gist.github.com/andytill/3835914