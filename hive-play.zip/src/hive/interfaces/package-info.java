/**
 * Interfaces.
 * <p>
 * Created at 25/03/16 09:36
 *
 * @author <a href="mailto:pieterdeclercq@outlook.com">Pieter De Clercq</a>
 */
package hive.interfaces;