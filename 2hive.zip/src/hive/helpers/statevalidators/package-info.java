/**
 * Validators for the current BoardState.
 * <p>
 * Created at 30/04/16 10:59
 *
 * @author <a href="mailto:pieterdeclercq@outlook.com">Pieter De Clercq</a>
 */
package hive.helpers.statevalidators;