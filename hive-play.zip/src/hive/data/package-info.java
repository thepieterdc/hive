/**
 * Data enums.
 * <p>
 * Created at 16/03/16 18:47
 *
 * @author <a href="mailto:pieterdeclercq@outlook.com">Pieter De Clercq</a>
 */
package hive.data;