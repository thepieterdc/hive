/**
 * MVC pattern models.
 * <p>
 * Created at 16/03/16 23:08
 *
 * @author <a href="mailto:pieterdeclercq@outlook.com">Pieter De Clercq</a>
 */
package hive.models;