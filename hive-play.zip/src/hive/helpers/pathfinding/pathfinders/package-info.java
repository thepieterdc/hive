/**
 * PathFinders for different units.
 * <p>
 * Created at 29/04/16 19:03
 *
 * @author <a href="mailto:pieterdeclercq@outlook.com">Pieter De Clercq</a>
 */
package hive.helpers.pathfinding.pathfinders;