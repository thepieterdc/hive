# hive2
MVC version of Hive (final)
