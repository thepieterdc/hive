/**
 * Custom components.
 * <p>
 * Created at 16/03/16 19:58
 *
 * @author <a href="mailto:pieterdeclercq@outlook.com">Pieter De Clercq</a>
 */
package hive.components;